// src/components/CharacterAvatar.js
// 캐릭터 아바타 - 원형 배경, 또렷한 이미지, 탭하면 변경

import React, { useState } from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { CHARACTERS, CHARACTER_LIST } from '../constants/characters';

/**
 * @param {string} characterId - 'toru', 'paengi', 'taco', 'totoru'
 * @param {number} size - 아바타 크기 (기본 56)
 * @param {string} mood - 'happy', 'normal', 'sad', 'sleep', 'splus'
 * @param {boolean} tappable - 탭하면 캐릭터 변경 (기본 false)
 * @param {function} onCharChange - 캐릭터 변경 콜백
 */
export default function CharacterAvatar({
  characterId = 'toru',
  size = 56,
  mood = 'normal',
  tappable = false,
  onCharChange,
}) {
  const [localIdx, setLocalIdx] = useState(() => {
    const idx = CHARACTER_LIST.indexOf(characterId);
    return idx >= 0 ? idx : 0;
  });

  const currentId = tappable ? CHARACTER_LIST[localIdx % CHARACTER_LIST.length] : characterId;
  const char = CHARACTERS[currentId] || CHARACTERS.toru;

  const handleTap = () => {
    if (!tappable) return;
    const next = (localIdx + 1) % CHARACTER_LIST.length;
    setLocalIdx(next);
    onCharChange?.(CHARACTER_LIST[next]);
  };

  const Wrapper = tappable ? TouchableOpacity : View;
  const wrapProps = tappable ? { onPress: handleTap, activeOpacity: 0.7 } : {};

  return (
    <Wrapper {...wrapProps} style={[styles.container, { width: size, height: size }]}>
      {/* 원형 배경 */}
      <View style={[
        styles.circle,
        { width: size, height: size, borderRadius: size / 2, backgroundColor: char.bgColor },
      ]}>
        <Image
          source={char.image}
          style={[
            styles.image,
            { width: size, height: size, borderRadius: size / 2 },
            mood === 'sad' && { opacity: 0.7 },
            mood === 'sleep' && { opacity: 0.5 },
          ]}
          resizeMode="cover"
        />
      </View>
      {/* 오버레이 이펙트 */}
      {mood === 'happy' && (
        <View style={[styles.overlay, { top: -2, right: -2 }]}>
          <Text style={{ fontSize: size * 0.25 }}>✨</Text>
        </View>
      )}
      {mood === 'splus' && (
        <View style={[styles.overlay, { top: -6, alignSelf: 'center' }]}>
          <Text style={{ fontSize: size * 0.3 }}>👑</Text>
        </View>
      )}
      {mood === 'sad' && (
        <View style={[styles.overlay, { bottom: 2, right: 0 }]}>
          <Text style={{ fontSize: size * 0.2 }}>💧</Text>
        </View>
      )}
      {mood === 'sleep' && (
        <View style={[styles.overlay, { top: -4, right: -4 }]}>
          <Text style={{ fontSize: size * 0.22 }}>💤</Text>
        </View>
      )}
    </Wrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  circle: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 0,
    
  },
  image: {},
  overlay: {
    position: 'absolute',
  },
});
