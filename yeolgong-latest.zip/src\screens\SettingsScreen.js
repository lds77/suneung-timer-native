// src/screens/SettingsScreen.js
// 탭 4: 설정

import React, { useState, useMemo } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  TextInput, Switch, Modal, Alert, StyleSheet, Platform, Linking,
} from 'react-native';
import { useApp } from '../hooks/useAppState';
import { LIGHT, DARK, getTheme } from '../constants/colors';
import { CHARACTERS, CHARACTER_LIST } from '../constants/characters';
import { DAILY_GOAL_OPTIONS } from '../constants/presets';
import { formatDDay, generateId } from '../utils/format';
import { clearAllData } from '../utils/storage';
import CharacterAvatar from '../components/CharacterAvatar';

export default function SettingsScreen() {
  const app = useApp();
  const T = getTheme(app.settings.darkMode, app.settings.accentColor, app.settings.fontScale);

  // D-Day 추가 모달 (캘린더 방식)
  const [showDDayModal, setShowDDayModal] = useState(false);
  const [ddLabel, setDdLabel] = useState('');
  const [ddDays, setDdDays] = useState(1);
  const [pickerMonth, setPickerMonth] = useState(new Date());
  const [pickerSelected, setPickerSelected] = useState(null);
  const today = new Date().toISOString().split('T')[0];

  const DDAY_PRESETS = [
    { label: '수능 2026', date: '2026-11-19' },
    { label: '중간고사', date: null }, { label: '기말고사', date: null }, { label: '모의고사', date: null },
  ];

  const pickerStr = `${pickerMonth.getFullYear()}.${String(pickerMonth.getMonth() + 1).padStart(2, '0')}`;
  const pickerCells = useMemo(() => {
    const y = pickerMonth.getFullYear(), m = pickerMonth.getMonth();
    const first = new Date(y, m, 1), last = new Date(y, m + 1, 0);
    const cells = Array(first.getDay()).fill(null);
    for (let d = 1; d <= last.getDate(); d++) cells.push({ day: d, date: `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}` });
    return cells;
  }, [pickerMonth]);

  const handleAddDDay = () => {
    if (!ddLabel.trim() || !pickerSelected) { app.showToastCustom('이름과 날짜를 선택하세요', 'paengi'); return; }
    if (app.ddays.length >= 10) { app.showToastCustom('D-Day는 최대 10개까지!', 'paengi'); return; }
    app.addDDay({ label: ddLabel.trim(), date: pickerSelected, days: ddDays });
    setDdLabel(''); setPickerSelected(null); setDdDays(1);
    setShowDDayModal(false);
    app.showToastCustom('D-Day 추가 완료!', 'taco');
  };

  const handleDeleteDDay = (dd) => {
    Alert.alert('D-Day 삭제', `"${dd.label}"을 삭제할까요?`, [
      { text: '취소', style: 'cancel' },
      { text: '삭제', style: 'destructive', onPress: () => app.removeDDay(dd.id) },
    ]);
  };

  const handleReset = () => {
    Alert.alert(
      '전체 데이터 초기화',
      '모든 과목, 세션 기록, 설정이 삭제됩니다.\n이 작업은 되돌릴 수 없어요!',
      [
        { text: '취소', style: 'cancel' },
        {
          text: '초기화',
          style: 'destructive',
          onPress: async () => {
            await clearAllData();
            app.showToastCustom('초기화 완료. 앱을 다시 시작해주세요.', 'totoru');
          },
        },
      ],
    );
  };

  // 설정 아이템 렌더링
  const Section = ({ title, children }) => (
    <View style={[styles.section, { borderColor: T.border }]}>
      <Text style={[styles.sectionTitle, { color: T.sub }]}>{title}</Text>
      {children}
    </View>
  );

  const Row = ({ label, right, onPress }) => (
    <TouchableOpacity
      style={styles.row}
      onPress={onPress}
      disabled={!onPress}
      activeOpacity={onPress ? 0.6 : 1}
    >
      <Text style={[styles.rowLabel, { color: T.text }]}>{label}</Text>
      <View style={styles.rowRight}>{right}</View>
    </TouchableOpacity>
  );

  return (
    <View style={[styles.container, { backgroundColor: T.bg }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        <Text style={[styles.headerTitle, { color: T.text }]}>⚙️ 설정</Text>

        {/* 캐릭터 */}
        <Section title="캐릭터">
          <View style={styles.charGrid}>
            {CHARACTER_LIST.map(cId => {
              const c = CHARACTERS[cId];
              const isActive = app.settings.mainCharacter === cId;
              return (
                <TouchableOpacity
                  key={cId}
                  style={[
                    styles.charCard,
                    {
                      backgroundColor: isActive ? c.bgColor : T.card,
                      borderColor: isActive ? T.accent : T.border,
                      borderWidth: isActive ? 2 : 1,
                    },
                  ]}
                  onPress={() => app.updateSettings({ mainCharacter: cId })}
                >
                  <CharacterAvatar characterId={cId} size={40} mood={isActive ? 'happy' : 'normal'} />
                  <Text style={[
                    styles.charName,
                    { color: isActive ? T.accent : T.sub, fontWeight: isActive ? '800' : '600' },
                  ]}>
                    {c.name}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </Section>

        {/* 목표 */}
        <Section title="목표">
          <Text style={[styles.goalLabel, { color: T.sub }]}>일일 목표 시간</Text>
          <View style={styles.goalRow}>
            {DAILY_GOAL_OPTIONS.map(min => (
              <TouchableOpacity
                key={min}
                style={[
                  styles.goalBtn,
                  {
                    borderColor: app.settings.dailyGoalMin === min ? T.accent : T.border,
                    backgroundColor: app.settings.dailyGoalMin === min ? T.accent : T.card,
                  },
                ]}
                onPress={() => app.updateSettings({ dailyGoalMin: min })}
              >
                <Text style={[
                  styles.goalBtnText,
                  { color: app.settings.dailyGoalMin === min ? 'white' : T.sub },
                ]}>
                  {min / 60}시간
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Section>

        {/* D-Day */}
        <Section title={`D-Day (${app.ddays.length}/10)`}>
          {app.ddays.map(dd => (
            <View key={dd.id} style={[styles.ddayRow, { borderColor: T.border }]}>
              <TouchableOpacity onPress={() => app.setPrimaryDDay(dd.id)} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Text style={{ color: dd.isPrimary ? T.gold : T.border, fontSize: 16 }}>★</Text>
                <View><Text style={[styles.ddayLabel, { color: T.text }]}>{dd.label}</Text>
                  <Text style={[styles.ddayDate, { color: T.sub }]}>{dd.date}{dd.days > 1 ? ` (${dd.days}일간)` : ''}</Text></View>
              </TouchableOpacity>
              <View style={{ flex: 1 }} />
              <Text style={[styles.ddayBadge, { color: T.accent }]}>{formatDDay(dd.date)}</Text>
              <TouchableOpacity onPress={() => handleDeleteDDay(dd)}>
                <Text style={[styles.ddayDel, { color: T.red }]}>×</Text>
              </TouchableOpacity>
            </View>
          ))}
          {app.ddays.length < 10 && (
            <TouchableOpacity
              style={[styles.ddayAddBtn, { borderColor: T.border }]}
              onPress={() => setShowDDayModal(true)}
            >
              <Text style={[styles.ddayAddText, { color: T.accent }]}>+ D-Day 추가</Text>
            </TouchableOpacity>
          )}
        </Section>

        {/* 타이머 기본값 */}
        <Section title="타이머 기본값">
          <Row
            label="뽀모도로 집중"
            right={<Text style={[styles.rowValue, { color: T.accent }]}>{app.settings.pomodoroWorkMin}분</Text>}
          />
          <Row
            label="뽀모도로 휴식"
            right={<Text style={[styles.rowValue, { color: T.accent }]}>{app.settings.pomodoroBreakMin}분</Text>}
          />
        </Section>

        {/* 알림 */}
        <Section title="알림">
          <Row
            label="타이머 완료 알림"
            right={
              <Switch
                value={app.settings.notifEnabled}
                onValueChange={(v) => app.updateSettings({ notifEnabled: v })}
                trackColor={{ true: T.accent }}
                thumbColor="white"
              />
            }
          />
        </Section>

        {/* 울트라 포커스 */}
        <Section title="울트라 포커스">
          <Row
            label="엄격 모드"
            right={
              <Switch
                value={app.settings.ultraFocusStrict}
                onValueChange={(v) => app.updateSettings({ ultraFocusStrict: v })}
                trackColor={{ true: T.accent }}
                thumbColor="white"
              />
            }
          />
          <Text style={[styles.hint, { color: T.sub }]}>
            엄격: 폰 들어올리면 즉시 이탈 / 일반: 30초 유예
          </Text>
        </Section>

        {/* 학교급 */}
        <Section title="학교급">
          <View style={{ flexDirection: 'row', gap: 6, paddingHorizontal: 16, paddingVertical: 8 }}>
            {[
              { id: 'elementary', label: '초등' },
              { id: 'middle', label: '중등' },
              { id: 'high', label: '고등' },
            ].map(s => {
              const sel = (app.settings.schoolLevel || 'high') === s.id;
              return (
                <TouchableOpacity key={s.id} onPress={() => app.updateSettings({ schoolLevel: s.id })}
                  style={{ flex: 1, paddingVertical: 10, borderRadius: 10, borderWidth: 1.5, borderColor: sel ? T.accent : T.border, backgroundColor: sel ? T.accent + '15' : 'transparent', alignItems: 'center' }}>
                  <Text style={{ fontSize: 13, fontWeight: sel ? '900' : '600', color: sel ? T.accent : T.text }}>{s.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </Section>

        {/* 테마 */}
        <Section title="테마">
          <Row
            label="다크 모드"
            right={
              <Switch
                value={app.settings.darkMode}
                onValueChange={(v) => app.updateSettings({ darkMode: v })}
                trackColor={{ true: T.accent }}
                thumbColor="white"
              />
            }
          />
          <View style={{ paddingHorizontal: 16, paddingVertical: 8 }}>
            <Text style={{ fontSize: 12, fontWeight: '700', color: T.text, marginBottom: 6 }}>테마 컬러</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
              {[
                { id: 'pink',   color: '#FF6B9D', label: '로즈핑크' },
                { id: 'purple', color: '#6C5CE7', label: '퍼플' },
                { id: 'blue',   color: '#4A90D9', label: '스카이블루' },
                { id: 'mint',   color: '#00B894', label: '민트' },
                { id: 'navy',   color: '#2C5F9E', label: '네이비' },
                { id: 'coral',  color: '#E07050', label: '코랄' },
              ].map(t => {
                const sel = (app.settings.accentColor || 'pink') === t.id;
                return (
                  <TouchableOpacity key={t.id} onPress={() => app.updateSettings({ accentColor: t.id })}
                    style={{ alignItems: 'center', gap: 4, minWidth: 44 }}>
                    <View style={{
                      width: 36, height: 36, borderRadius: 18,
                      backgroundColor: t.color,
                      borderWidth: sel ? 3 : 1.5,
                      borderColor: sel ? T.text : t.color + '80',
                      shadowColor: t.color, shadowOpacity: sel ? 0.5 : 0,
                      shadowRadius: 6, elevation: sel ? 4 : 0,
                    }} />
                    <Text style={{ fontSize: 9, fontWeight: sel ? '800' : '500', color: sel ? T.text : T.sub }}>{t.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
          <View style={{ paddingHorizontal: 16, paddingVertical: 8 }}>
            <Text style={{ fontSize: 12, fontWeight: '700', color: T.text, marginBottom: 6 }}>글꼴 크기 <Text style={{ fontSize: 9, color: T.sub }}>(다음 업데이트 적용)</Text></Text>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              {[
                { id: 'small', label: '작게', scale: 0.85 },
                { id: 'medium', label: '보통', scale: 1.0 },
                { id: 'large', label: '크게', scale: 1.15 },
              ].map(f => {
                const sel = (app.settings.fontScale || 'medium') === f.id;
                return (
                  <TouchableOpacity key={f.id} onPress={() => app.updateSettings({ fontScale: f.id })}
                    style={{ flex: 1, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: sel ? T.accent : T.border, backgroundColor: sel ? T.accent + '15' : 'transparent', alignItems: 'center' }}>
                    <Text style={{ fontSize: 12 * f.scale, fontWeight: sel ? '800' : '500', color: sel ? T.accent : T.text }}>{f.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        </Section>

        {/* 데이터 */}
        <Section title="데이터">
          <TouchableOpacity style={styles.dangerBtn} onPress={handleReset}>
            <Text style={[styles.dangerText, { color: T.red }]}>전체 데이터 초기화</Text>
          </TouchableOpacity>
        </Section>

        {/* 정보 */}
        <Section title="정보">
          <Row label="버전" right={<Text style={[styles.rowValue, { color: T.sub }]}>1.0.0</Text>} />
          <TouchableOpacity onPress={() => Linking.openURL('https://lds77.github.io/suneung-timer-native/privacy-policy.html')}>
            <Row label="개인정보 처리방침" right={<Text style={{ color: T.sub }}>→</Text>} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Linking.openURL('mailto:leedongsik@example.com?subject=열공 멀티타이머 피드백')}>
            <Row label="피드백 보내기" right={<Text style={{ color: T.sub }}>→</Text>} />
          </TouchableOpacity>
        </Section>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* D-Day 추가 모달 (캘린더 피커) */}
      <Modal visible={showDDayModal} transparent animationType="fade">
        <View style={styles.modalOverlay}><ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center' }}><View style={[styles.modal, { backgroundColor: T.card, borderColor: T.border }]}>
            <Text style={[styles.modalTitle, { color: T.text }]}>📅 D-Day 추가</Text>
            {/* 프리셋 */}
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginBottom: 8 }}>{DDAY_PRESETS.map(p => (
              <TouchableOpacity key={p.label} style={{ paddingHorizontal: 8, paddingVertical: 5, borderRadius: 6, borderWidth: 1, borderColor: ddLabel === p.label ? T.accent : T.border }}
                onPress={() => { setDdLabel(p.label); if (p.date) setPickerSelected(p.date); }}>
                <Text style={{ fontSize: 10, fontWeight: '700', color: ddLabel === p.label ? T.accent : T.sub }}>{p.label}</Text></TouchableOpacity>
            ))}</View>
            <TextInput value={ddLabel} onChangeText={setDdLabel} placeholder="이름 (예: 중간고사)" placeholderTextColor={T.sub} maxLength={15}
              style={[styles.modalInput, { borderColor: T.border, backgroundColor: T.surface, color: T.text }]} />
            {/* 캘린더 */}
            <View style={{ backgroundColor: T.surface, borderRadius: 10, padding: 8, borderWidth: 1, borderColor: T.border, marginBottom: 8 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <TouchableOpacity onPress={() => setPickerMonth(p => { const d = new Date(p); d.setMonth(d.getMonth()-1); return d; })}><Text style={{ color: T.accent, fontSize: 16, paddingHorizontal: 8 }}>◀</Text></TouchableOpacity>
                <Text style={{ color: T.text, fontSize: 13, fontWeight: '800' }}>{pickerStr}</Text>
                <TouchableOpacity onPress={() => setPickerMonth(p => { const d = new Date(p); d.setMonth(d.getMonth()+1); return d; })}><Text style={{ color: T.accent, fontSize: 16, paddingHorizontal: 8 }}>▶</Text></TouchableOpacity></View>
              <View style={{ flexDirection: 'row', marginBottom: 2 }}>{'일월화수목금토'.split('').map(d => <Text key={d} style={{ flex: 1, textAlign: 'center', fontSize: 9, color: T.sub, fontWeight: '600' }}>{d}</Text>)}</View>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>{pickerCells.map((cell, i) => {
                if (!cell) return <View key={`e${i}`} style={{ width: '14.28%', height: 32 }} />;
                const sel = pickerSelected === cell.date, past = cell.date < today;
                return (<TouchableOpacity key={cell.date} style={{ width: '14.28%', height: 32, alignItems: 'center', justifyContent: 'center' }} onPress={() => !past && setPickerSelected(cell.date)} disabled={past}>
                  <View style={[{ width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, sel && { backgroundColor: T.accent }, past && { opacity: 0.3 }]}>
                    <Text style={{ fontSize: 11, fontWeight: sel ? '800' : '500', color: sel ? 'white' : T.text }}>{cell.day}</Text></View></TouchableOpacity>);
              })}</View>
            </View>
            {pickerSelected && <Text style={{ fontSize: 10, color: T.accent, textAlign: 'center', marginBottom: 6, fontWeight: '700' }}>선택: {pickerSelected}</Text>}
            {/* 날짜 직접 입력 */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <Text style={{ fontSize: 10, color: T.sub }}>직접 입력:</Text>
              <TextInput
                placeholder="2026-06-15"
                placeholderTextColor={T.sub}
                value={pickerSelected || ''}
                onChangeText={(v) => {
                  if (/^\d{4}-\d{2}-\d{2}$/.test(v) && !isNaN(new Date(v+'T00:00:00').getTime())) {
                    setPickerSelected(v);
                    const d = new Date(v+'T00:00:00');
                    setPickerMonth(new Date(d.getFullYear(), d.getMonth(), 1));
                  } else if (v.length <= 10) {
                    setPickerSelected(v);
                  }
                }}
                style={{ flex: 1, borderWidth: 1, borderColor: T.border, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4, fontSize: 12, color: T.text, backgroundColor: T.surface2 }}
                maxLength={10}
              />
            </View>
            {/* 기간 */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <Text style={{ fontSize: 11, color: T.sub }}>시험 기간</Text>
              <View style={{ flexDirection: 'row', gap: 3 }}>{[1,2,3,4,5].map(n => (
                <TouchableOpacity key={n} style={{ paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, borderWidth: 1, borderColor: ddDays === n ? T.accent : T.border, backgroundColor: ddDays === n ? T.accent : 'transparent' }}
                  onPress={() => setDdDays(n)}><Text style={{ fontSize: 10, fontWeight: '700', color: ddDays === n ? 'white' : T.sub }}>{n}일</Text></TouchableOpacity>
              ))}</View></View>
            <View style={styles.modalBtns}>
              <TouchableOpacity style={[styles.modalCancel, { borderColor: T.border }]} onPress={() => { setShowDDayModal(false); setDdLabel(''); setPickerSelected(null); setDdDays(1); }}>
                <Text style={[styles.modalCancelText, { color: T.sub }]}>취소</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.modalConfirm, { backgroundColor: T.accent }]} onPress={handleAddDDay}>
                <Text style={styles.modalConfirmText}>추가</Text></TouchableOpacity></View>
          </View></ScrollView></View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 16, paddingTop: 8 },
  headerTitle: { fontSize: 20, fontWeight: '900', marginBottom: 12 },

  section: { marginBottom: 16, paddingBottom: 12, borderBottomWidth: 1 },
  sectionTitle: { fontSize: 11, fontWeight: '700', marginBottom: 8, textTransform: 'uppercase' },

  // 캐릭터 선택
  charGrid: { flexDirection: 'row', gap: 6 },
  charCard: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 12 },
  charName: { fontSize: 10, marginTop: 4 },

  // 목표
  goalLabel: { fontSize: 10, marginBottom: 6 },
  goalRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 5 },
  goalBtn: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6, borderWidth: 1 },
  goalBtnText: { fontSize: 10, fontWeight: '700' },

  // D-Day
  ddayRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 6, borderBottomWidth: 0.5 },
  ddayStar: { padding: 2 },
  ddayLabel: { fontSize: 13, fontWeight: '700' },
  ddayDate: { fontSize: 10, marginTop: 1 },
  ddayBadge: { fontSize: 11, fontWeight: '800' },
  ddayDel: { fontSize: 18, paddingHorizontal: 4 },
  ddayAddBtn: { paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderStyle: 'dashed', alignItems: 'center', marginTop: 6 },
  ddayAddText: { fontSize: 12, fontWeight: '700' },

  // Row
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8 },
  rowLabel: { fontSize: 13, fontWeight: '600' },
  rowRight: {},
  rowValue: { fontSize: 13, fontWeight: '700' },

  hint: { fontSize: 9, marginTop: -4, marginBottom: 4 },

  // 위험 버튼
  dangerBtn: { paddingVertical: 10, alignItems: 'center' },
  dangerText: { fontSize: 13, fontWeight: '600' },

  // 모달
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', paddingHorizontal: 30 },
  modal: { borderRadius: 20, padding: 20, borderWidth: 1 },
  modalTitle: { fontSize: 16, fontWeight: '900', textAlign: 'center', marginBottom: 14 },
  modalInput: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14, marginBottom: 10 },
  modalBtns: { flexDirection: 'row', gap: 8, marginTop: 4 },
  modalCancel: { flex: 1, paddingVertical: 11, borderRadius: 10, borderWidth: 1, alignItems: 'center' },
  modalCancelText: { fontSize: 13, fontWeight: '600' },
  modalConfirm: { flex: 1, paddingVertical: 11, borderRadius: 10, alignItems: 'center' },
  modalConfirmText: { color: 'white', fontSize: 13, fontWeight: '800' },
});
